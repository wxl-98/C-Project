
#ifndef _MY_LS_H
#define _MY_LS_H

void my_ls (int n, char *arg[]);

#endif
