
#ifndef _MY_CD_H
#define _MY_CD_H

void my_cd (int n, char *str[]);

#endif
